﻿using System;
using System.IO;

namespace EU
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] file = File.ReadAllLines("EUcsatlakozas.txt");
            string[,] adatok = new string[file.Length, 2];
            int csatlakozasszamolo = 0;
            int adottevcsatlakozo = 0;
            string datumcsat = "";
            bool volt = false;
            int maxev = 0, maxhonap = 0, maxnap = 0;
            string orszagnev = "";
            for(int i  = 0; i < file.Length;i++)
            {
                string[] split = file[i].Split(';'); string nev = "";
                adatok[i, 0] = split[0];
                adatok[i, 1] = split[1];
                string[] datumsplit = split[1].Split('.');
                int adottev = Convert.ToInt32(datumsplit[0]);
                int adotthonap = Convert.ToInt32(datumsplit[1]);
                int adottnap = Convert.ToInt32(datumsplit[2]);
                nev = split[0];
                if (adottev <= 2018)
                    csatlakozasszamolo++;

                if (adottev == 2007)
                    adottevcsatlakozo++;
                nev = Convert.ToString(split[0]);
                if (nev == "Magyarorszag" ||split[1] == "2004.05.01")
                {
                    datumcsat = adatok[i, 1];
                }

                if (adotthonap == 5)
                    volt = true;

                if(maxev <= adottev && maxhonap <= adotthonap && maxnap <= adottnap)
                {
                    maxev = adottev; maxhonap = adotthonap; maxnap = adottnap;
                    orszagnev = Convert.ToString(split[0]);
                }

            }

            int[,] statisztika = new int[file.Length, 2];
            int szamolo = 0;
            for (int i = 0; i < file.Length; i++)
            {
                int jodb = 0;
                string[] split = adatok[i, 1].Split('.');
                int ev = Convert.ToInt32(split[0]);
                int honap = Convert.ToInt32(split[1]);
                int nap = Convert.ToInt32(split[2]);
                int y = 0;
                string[] spliter = adatok[0, 1].Split('.');
                int kezdoev = Convert.ToInt32(spliter[0]);
                /*statisztika[0, 0] = kezdoev;
                statisztika[0, 1] = 1;*/
                for (y = 0; y <= 27; y++)
                {
                    if (ev == statisztika[y, 0])
                    {
                        statisztika[y, 1]++;
                        jodb++;
                    }
                }
                if (jodb == 0)
                {
                    szamolo++;
                    statisztika[szamolo, 0] = ev;
                    statisztika[szamolo, 1] = 1;

                }
            }

            

            Console.WriteLine("3.feladat : EU tagállamainak száma : {0} db", csatlakozasszamolo);
            Console.WriteLine("4.feladat : 2007-ben {0} ország csatlakozott", adottevcsatlakozo);
            Console.WriteLine("5.feladat : Magyarország {0} kor csatlakozott", datumcsat);
            if (volt == true)
                Console.WriteLine("6.feladat : Volt májusban csatlakozás");
            else
                Console.WriteLine("6.feladat : Nem volt májusban csatlakozás");
            Console.WriteLine("7.feladat : A legutoljára csatlakozott ország : {0}", orszagnev);
            Console.WriteLine("8.feladat : statisztika");
            for (int i = 1; i < szamolo + 1; i++)
            {
                Console.WriteLine("{0} - {1} ország", statisztika[i, 0], statisztika[i, 1]);
            }


            Console.ReadLine();

        }
    }
}
